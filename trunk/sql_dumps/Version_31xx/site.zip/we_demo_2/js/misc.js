function openBrWindowFever(theURL,winName,features,ref,center){
  eval("var "+winName);	if (eval(winName)==true && !winName.closed)
  {winName.focus();}else{if(ref){
  var refURL=theURL+"?URL="+document.location;}else{var refURL=theURL;}
  if(center!="vals"){a=new Array();a=center.split('|');
  t=((screen.height)-a[0])/2;l=((screen.width)-a[1])/2;
  features=features+",top="+t+",left="+l;}
  winName=window.open(refURL,winName,features);
  winName.focus();winName = true;}
}

function CheckSupportFormular()
{
  with(document.forms[0])
  {
    if(anrede.selectedIndex == 0)
    {
      anrede.focus();
      alert("Bitte w�hlen Sie eine Anrede aus.");
      return false;
    }
    if(vorname.value == "")
    {
      vorname.focus();
      alert("Bitte geben Sie Ihren Vornamen an.");
      return false;
    }
    if(nachname.value == "")
    {
      nachname.focus();
      alert("Bitte geben Sie Ihren Nachnamen an.");
      return false;
    } 
    if(email.value == "")
    {
      email.focus();
      alert("Bitte geben Sie Ihre E-Mail-Adresse an.");
      return false;
    }
    if(email.value != "")
    {
      reg = new RegExp('^([a-zA-Z0-9\\-\\.\\_]+)'+'(\\@)([a-zA-Z0-9\\-\\.]+)'+'(\\.)([a-zA-Z]{2,4})$');
      res = (reg.test(email.value));
      if(!res)
      {
        email.focus();
        alert("Bitte �berpr�fen Sie Ihre E-Mail-Adresse.");
        return false;
      }
    }
    if(produkt.selectedIndex == 0)
    {
      produkt.focus();
      alert("Bitte w�hlen Sie das Produkt aus, zu welchem Sie eine Frage haben.");
      return false;
    }
    if(mitteilung.value == "")
    {
      mitteilung.focus;
      alert("Bitte geben Sie Ihre Mitteilung ein.");
      return false;
    }
    else
      submit();
  }
}

function CheckGaestebuchFormular()
{
  with(document.forms[0])
  {
    if(elements["we_ui_we_global_form[Name]"].value.length == 0)
    {
      alert("Bitte geben Sie Ihren Namen ein!");
      elements["we_ui_we_global_form[Name]"].focus();
      return false;
    }
    if(elements["we_ui_we_global_form[EMail]"].value.length != 0)
    {
      reg = new RegExp('^([a-zA-Z0-9\\-\\.\\_]+)'+'(\\@)([a-zA-Z0-9\\-\\.]+)'+'(\\.)([a-zA-Z]{2,4})$');
      res = (reg.test(elements["we_ui_we_global_form[EMail]"].value));
      if(!res)
      {
        elements["we_ui_we_global_form[EMail]"].focus();
        alert("Bitte �berpr�fen Sie Ihre E-Mail-Adresse.");
        return false;
      }
    }
    if(elements["we_ui_we_global_form[Ort]"].value.length == 0)
    {
      alert("Bitte geben Sie Ihren Ort ein!");
      elements["we_ui_we_global_form[Ort]"].focus();
      return false;
    }
    if(elements["we_ui_we_global_form[Text]"].value.length == 0)
    {
      alert("Bitte geben Sie einen Text ein!");
      elements["we_ui_we_global_form[Text]"].focus();
      return false;
    }
    else
    {
      submit();
    }
  }
}

function HideLinkFocus()
{
  if(document.all)
  {
    for(var i = 0; i < document.links.length; i++)
     document.links[i].hideFocus = true;
  }
}