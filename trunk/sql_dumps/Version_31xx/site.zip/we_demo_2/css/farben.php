<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>Farbtabelle</TITLE>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body,td,th { font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px; color: #000000; }
th { font-weight: bold; }
a { color: #000000; }
-->
</style>
</HEAD>
<BODY style="background-color: #FFFFFF;">
<TABLE cellSpacing="1" cellPadding="5" border="0" align="left">
  <TBODY>
    <TR> 
      <TD vAlign="top" nowrap> <P><b>Bitte w&auml;hlen sie die Farbe von der Sie 
          den Wert wissen wollen</b> 
        <UL>
          <LI><A href="#Black"><b>Schwarz</b> + Abstufungen</a></LI>
          <LI><A href="#Blue"><b>Blau</b> + Abstufungen</a></LI>
          <LI><A href="#Brown"><b>Braun</b> + Abstufungen</a></LI>
          <LI><A href="#Gray"><b>Grau</b> + Abstufungen</a></LI>
          <LI><A href="#Green"><b>Gr�n</b> + Abstufungen</a></LI>
          <LI><A href="#Orange"><b>Orange</b> + Abstufungen</a></LI>
          <LI><A href="#Red"><b>Rot</b> + Abstufungen</a></LI>
          <LI><A href="#Violet"><b>Violett</b> + Abstufungen</a></LI>
          <LI><A href="#White"><b>Wei�</b> + Abstufungen</a></LI>
          <LI><A href="#Yellow"><b>Gelb</b> + Abstufungen</a></LI>
        </UL>
        <HR width="100%" noShade align="left"><P><A href="#top" name=Black>[Zur&uuml;ck 
          zur Farb&uuml;bersicht]</A></p>
        <TABLE cellPadding="3" width="100%" border="1">
          <TBODY>
            <TR> 
              <TH colSpan="2">Schattierungen von Schwarz</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#000000</td>
              <td bgcolor="#000000" width="50%">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name="Blue">[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p>
        <TABLE cellPadding="3" width="100%" border="1">
          <TBODY>
            <TR> 
              <TH colSpan="2">Schattierungen von Blau</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F0F8FF</td>
              <td bgcolor="#f0f8ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8A2BE2</td>
              <td bgcolor="#8a2be2" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#5F9EA0</td>
              <td bgcolor="#5f9ea0" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#98F5FF</td>
              <td bgcolor="#98f5ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8EE5EE</td>
              <td bgcolor="#8ee5ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7AC5CD</td>
              <td bgcolor="#7ac5cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#53868B</td>
              <td bgcolor="#53868b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6495ED</td>
              <td bgcolor="#6495ed" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#483D8B</td>
              <td bgcolor="#483d8b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00CED1</td>
              <td bgcolor="#00ced1" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00BFFF</td>
              <td bgcolor="#00bfff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00BFFF</td>
              <td bgcolor="#00bfff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00B2EE</td>
              <td bgcolor="#00b2ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#009ACD</td>
              <td bgcolor="#009acd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00688B</td>
              <td bgcolor="#00688b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#1E90FF</td>
              <td bgcolor="#1e90ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#1C86EE</td>
              <td bgcolor="#1c86ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#1874CD</td>
              <td bgcolor="#1874cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#104E8B</td>
              <td bgcolor="#104e8b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#ADD8E6</td>
              <td bgcolor="#add8e6" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BFEFFF</td>
              <td bgcolor="#bfefff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B2DFEE</td>
              <td bgcolor="#b2dfee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9AC0CD</td>
              <td bgcolor="#9ac0cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#68838B</td>
              <td bgcolor="#68838b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E0FFFF</td>
              <td bgcolor="#e0ffff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D1EEEE</td>
              <td bgcolor="#d1eeee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B4CDCD</td>
              <td bgcolor="#b4cdcd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7A8B8B</td>
              <td bgcolor="#7a8b8b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#87CEFA</td>
              <td bgcolor="#87cefa" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B0E2FF</td>
              <td bgcolor="#b0e2ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A4D3EE</td>
              <td bgcolor="#a4d3ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8DB6CD</td>
              <td bgcolor="#8db6cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#607B8B</td>
              <td bgcolor="#607b8b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8470FF</td>
              <td bgcolor="#8470ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B0C4DE</td>
              <td bgcolor="#b0c4de" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CAE1FF</td>
              <td bgcolor="#cae1ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BCD2EE</td>
              <td bgcolor="#bcd2ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A2B5CD</td>
              <td bgcolor="#a2b5cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6E7B8B</td>
              <td bgcolor="#6e7b8b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#66CDAA</td>
              <td bgcolor="#66cdaa" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0000CD</td>
              <td bgcolor="#0000cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7B68EE</td>
              <td bgcolor="#7b68ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#48D1CC</td>
              <td bgcolor="#48d1cc" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#191970</td>
              <td bgcolor="#191970" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#000080</td>
              <td bgcolor="#000080" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#AFEEEE</td>
              <td bgcolor="#afeeee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BBFFFF</td>
              <td bgcolor="#bbffff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#AEEEEE</td>
              <td bgcolor="#aeeeee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#96CDCD</td>
              <td bgcolor="#96cdcd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#668B8B</td>
              <td bgcolor="#668b8b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B0E0E6</td>
              <td bgcolor="#b0e0e6" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4169E1</td>
              <td bgcolor="#4169e1" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4876FF</td>
              <td bgcolor="#4876ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#436EEE</td>
              <td bgcolor="#436eee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#3A5FCD</td>
              <td bgcolor="#3a5fcd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#27408B</td>
              <td bgcolor="#27408b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#87CEEB</td>
              <td bgcolor="#87ceeb" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#87CEFF</td>
              <td bgcolor="#87ceff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7EC0EE</td>
              <td bgcolor="#7ec0ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6CA6CD</td>
              <td bgcolor="#6ca6cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4A708B</td>
              <td bgcolor="#4a708b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6A5ACD</td>
              <td bgcolor="#6a5acd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#836FFF</td>
              <td bgcolor="#836fff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7A67EE</td>
              <td bgcolor="#7a67ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6959CD</td>
              <td bgcolor="#6959cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#473C8B</td>
              <td bgcolor="#473c8b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4682B4</td>
              <td bgcolor="#4682b4" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#63B8FF</td>
              <td bgcolor="#63b8ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#5CACEE</td>
              <td bgcolor="#5cacee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4F94CD</td>
              <td bgcolor="#4f94cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#36648B</td>
              <td bgcolor="#36648b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7FFFD4</td>
              <td bgcolor="#7fffd4" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#76EEC6</td>
              <td bgcolor="#76eec6" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#66CDAA</td>
              <td bgcolor="#66cdaa" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#458B74</td>
              <td bgcolor="#458b74" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F0FFFF</td>
              <td bgcolor="#f0ffff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E0EEEE</td>
              <td bgcolor="#e0eeee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C1CDCD</td>
              <td bgcolor="#c1cdcd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#838B8B</td>
              <td bgcolor="#838b8b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0000FF</td>
              <td bgcolor="#0000ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0000EE</td>
              <td bgcolor="#0000ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0000CD</td>
              <td bgcolor="#0000cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00008B</td>
              <td bgcolor="#00008b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00FFFF</td>
              <td bgcolor="#00ffff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00EEEE</td>
              <td bgcolor="#00eeee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00CDCD</td>
              <td bgcolor="#00cdcd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#008B8B</td>
              <td bgcolor="#008b8b" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#000080</td>
              <td bgcolor="#000080" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#40E0D0</td>
              <td bgcolor="#40e0d0" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00F5FF</td>
              <td bgcolor="#00f5ff" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00E5EE</td>
              <td bgcolor="#00e5ee" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00C5CD</td>
              <td bgcolor="#00c5cd" width="50%">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00868B</td>
              <td bgcolor="#00868b" width="50%">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name=Brown>[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p>
        <TABLE cellPadding=3 width="100%" border=1>
          <TBODY>
            <TR> 
              <TH colSpan=2>Schattierungen von Braun</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BC8F8F</td>
              <td width="50%" bgcolor="#bc8f8f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFC1C1</td>
              <td width="50%" bgcolor="#ffc1c1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEB4B4</td>
              <td width="50%" bgcolor="#eeb4b4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD9B9B</td>
              <td width="50%" bgcolor="#cd9b9b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B6969</td>
              <td width="50%" bgcolor="#8b6969">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B4513</td>
              <td width="50%" bgcolor="#8b4513">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F4A460</td>
              <td width="50%" bgcolor="#f4a460">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F5F5DC</td>
              <td width="50%" bgcolor="#f5f5dc">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A52A2A</td>
              <td width="50%" bgcolor="#a52a2a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF4040</td>
              <td width="50%" bgcolor="#ff4040">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE3B3B</td>
              <td width="50%" bgcolor="#ee3b3b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD3333</td>
              <td width="50%" bgcolor="#cd3333">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B2323</td>
              <td width="50%" bgcolor="#8b2323">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DEB887</td>
              <td width="50%" bgcolor="#deb887">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFD39B</td>
              <td width="50%" bgcolor="#ffd39b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEC591</td>
              <td width="50%" bgcolor="#eec591">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDAA7D</td>
              <td width="50%" bgcolor="#cdaa7d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B7355</td>
              <td width="50%" bgcolor="#8b7355">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D2691E</td>
              <td width="50%" bgcolor="#d2691e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF7F24</td>
              <td width="50%" bgcolor="#ff7f24">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE7621</td>
              <td width="50%" bgcolor="#ee7621">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD661D</td>
              <td width="50%" bgcolor="#cd661d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B4513</td>
              <td width="50%" bgcolor="#8b4513">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD853F</td>
              <td width="50%" bgcolor="#cd853f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D2B48C</td>
              <td width="50%" bgcolor="#d2b48c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFA54F</td>
              <td width="50%" bgcolor="#ffa54f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE9A49</td>
              <td width="50%" bgcolor="#ee9a49">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD853F</td>
              <td width="50%" bgcolor="#cd853f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B5A2B</td>
              <td width="50%" bgcolor="#8b5a2b">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name=Gray>[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p> 
        <TABLE cellPadding=3 width="100%" border=1>
          <TBODY>
            <TR> 
              <TH colSpan=2>Schattierungen von Grau</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#2F4F4F</td>
              <td width="50%" bgcolor="#2f4f4f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#97FFFF</td>
              <td width="50%" bgcolor="#97ffff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8DEEEE</td>
              <td width="50%" bgcolor="#8deeee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#79CDCD</td>
              <td width="50%" bgcolor="#79cdcd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#528B8B</td>
              <td width="50%" bgcolor="#528b8b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#2F4F4F</td>
              <td width="50%" bgcolor="#2f4f4f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#696969</td>
              <td width="50%" bgcolor="#696969">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D3D3D3</td>
              <td width="50%" bgcolor="#d3d3d3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#778899</td>
              <td width="50%" bgcolor="#778899">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#708090</td>
              <td width="50%" bgcolor="#708090">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C6E2FF</td>
              <td width="50%" bgcolor="#c6e2ff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B9D3EE</td>
              <td width="50%" bgcolor="#b9d3ee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9FB6CD</td>
              <td width="50%" bgcolor="#9fb6cd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6C7B8B</td>
              <td width="50%" bgcolor="#6c7b8b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#708090</td>
              <td width="50%" bgcolor="#708090">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BEBEBE</td>
              <td width="50%" bgcolor="#bebebe">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#000000</td>
              <td width="50%" bgcolor="#000000">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#030303</td>
              <td width="50%" bgcolor="#030303">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#1A1A1A</td>
              <td width="50%" bgcolor="#1a1a1a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFFFFF</td>
              <td width="50%" bgcolor="#ffffff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#1C1C1C</td>
              <td width="50%" bgcolor="#1c1c1c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#1F1F1F</td>
              <td width="50%" bgcolor="#1f1f1f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#212121</td>
              <td width="50%" bgcolor="#212121">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#242424</td>
              <td width="50%" bgcolor="#242424">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#262626</td>
              <td width="50%" bgcolor="#262626">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#292929</td>
              <td width="50%" bgcolor="#292929">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#2B2B2B</td>
              <td width="50%" bgcolor="#2b2b2b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#2E2E2E</td>
              <td width="50%" bgcolor="#2e2e2e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#303030</td>
              <td width="50%" bgcolor="#303030">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#050505</td>
              <td width="50%" bgcolor="#050505">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#333333</td>
              <td width="50%" bgcolor="#333333">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#363636</td>
              <td width="50%" bgcolor="#363636">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#383838</td>
              <td width="50%" bgcolor="#383838">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#3B3B3B</td>
              <td width="50%" bgcolor="#3b3b3b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#3D3D3D</td>
              <td width="50%" bgcolor="#3d3d3d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#404040</td>
              <td width="50%" bgcolor="#404040">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#424242</td>
              <td width="50%" bgcolor="#424242">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#454545</td>
              <td width="50%" bgcolor="#454545">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#474747</td>
              <td width="50%" bgcolor="#474747">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4A4A4A</td>
              <td width="50%" bgcolor="#4a4a4a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#080808</td>
              <td width="50%" bgcolor="#080808">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4D4D4D</td>
              <td width="50%" bgcolor="#4d4d4d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4F4F4F</td>
              <td width="50%" bgcolor="#4f4f4f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#525252</td>
              <td width="50%" bgcolor="#525252">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#545454</td>
              <td width="50%" bgcolor="#545454">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#575757</td>
              <td width="50%" bgcolor="#575757">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#595959</td>
              <td width="50%" bgcolor="#595959">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#5C5C5C</td>
              <td width="50%" bgcolor="#5c5c5c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#5E5E5E</td>
              <td width="50%" bgcolor="#5e5e5e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#616161</td>
              <td width="50%" bgcolor="#616161">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#636363</td>
              <td width="50%" bgcolor="#636363">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0A0A0A</td>
              <td width="50%" bgcolor="#0a0a0a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#666666</td>
              <td width="50%" bgcolor="#666666">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#696969</td>
              <td width="50%" bgcolor="#696969">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6B6B6B</td>
              <td width="50%" bgcolor="#6b6b6b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6E6E6E</td>
              <td width="50%" bgcolor="#6e6e6e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#707070</td>
              <td width="50%" bgcolor="#707070">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#737373</td>
              <td width="50%" bgcolor="#737373">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#757575</td>
              <td width="50%" bgcolor="#757575">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#787878</td>
              <td width="50%" bgcolor="#787878">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7A7A7A</td>
              <td width="50%" bgcolor="#7a7a7a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7D7D7D</td>
              <td width="50%" bgcolor="#7d7d7d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0D0D0D</td>
              <td width="50%" bgcolor="#0d0d0d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7F7F7F</td>
              <td width="50%" bgcolor="#7f7f7f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#828282</td>
              <td width="50%" bgcolor="#828282">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#858585</td>
              <td width="50%" bgcolor="#858585">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#878787</td>
              <td width="50%" bgcolor="#878787">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8A8A8A</td>
              <td width="50%" bgcolor="#8a8a8a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8C8C8C</td>
              <td width="50%" bgcolor="#8c8c8c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8F8F8F</td>
              <td width="50%" bgcolor="#8f8f8f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#919191</td>
              <td width="50%" bgcolor="#919191">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#949494</td>
              <td width="50%" bgcolor="#949494">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#969696</td>
              <td width="50%" bgcolor="#969696">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0F0F0F</td>
              <td width="50%" bgcolor="#0f0f0f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#999999</td>
              <td width="50%" bgcolor="#999999">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9C9C9C</td>
              <td width="50%" bgcolor="#9c9c9c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9E9E9E</td>
              <td width="50%" bgcolor="#9e9e9e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A1A1A1</td>
              <td width="50%" bgcolor="#a1a1a1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A3A3A3</td>
              <td width="50%" bgcolor="#a3a3a3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A6A6A6</td>
              <td width="50%" bgcolor="#a6a6a6">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A8A8A8</td>
              <td width="50%" bgcolor="#a8a8a8">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#ABABAB</td>
              <td width="50%" bgcolor="#ababab">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#ADADAD</td>
              <td width="50%" bgcolor="#adadad">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B0B0B0</td>
              <td width="50%" bgcolor="#b0b0b0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#121212</td>
              <td width="50%" bgcolor="#121212">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B3B3B3</td>
              <td width="50%" bgcolor="#b3b3b3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B5B5B5</td>
              <td width="50%" bgcolor="#b5b5b5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B8B8B8</td>
              <td width="50%" bgcolor="#b8b8b8">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BABABA</td>
              <td width="50%" bgcolor="#bababa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BDBDBD</td>
              <td width="50%" bgcolor="#bdbdbd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BFBFBF</td>
              <td width="50%" bgcolor="#bfbfbf">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C2C2C2</td>
              <td width="50%" bgcolor="#c2c2c2">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C4C4C4</td>
              <td width="50%" bgcolor="#c4c4c4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C7C7C7</td>
              <td width="50%" bgcolor="#c7c7c7">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C9C9C9</td>
              <td width="50%" bgcolor="#c9c9c9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#141414</td>
              <td width="50%" bgcolor="#141414">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CCCCCC</td>
              <td width="50%" bgcolor="#cccccc">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CFCFCF</td>
              <td width="50%" bgcolor="#cfcfcf">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D1D1D1</td>
              <td width="50%" bgcolor="#d1d1d1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D4D4D4</td>
              <td width="50%" bgcolor="#d4d4d4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D6D6D6</td>
              <td width="50%" bgcolor="#d6d6d6">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D9D9D9</td>
              <td width="50%" bgcolor="#d9d9d9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DBDBDB</td>
              <td width="50%" bgcolor="#dbdbdb">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DEDEDE</td>
              <td width="50%" bgcolor="#dedede">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E0E0E0</td>
              <td width="50%" bgcolor="#e0e0e0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E3E3E3</td>
              <td width="50%" bgcolor="#e3e3e3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#171717</td>
              <td width="50%" bgcolor="#171717">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E5E5E5</td>
              <td width="50%" bgcolor="#e5e5e5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E8E8E8</td>
              <td width="50%" bgcolor="#e8e8e8">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EBEBEB</td>
              <td width="50%" bgcolor="#ebebeb">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EDEDED</td>
              <td width="50%" bgcolor="#ededed">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F0F0F0</td>
              <td width="50%" bgcolor="#f0f0f0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F2F2F2</td>
              <td width="50%" bgcolor="#f2f2f2">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F5F5F5</td>
              <td width="50%" bgcolor="#f5f5f5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F7F7F7</td>
              <td width="50%" bgcolor="#f7f7f7">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FAFAFA</td>
              <td width="50%" bgcolor="#fafafa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FCFCFC</td>
              <td width="50%" bgcolor="#fcfcfc">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BEBEBE</td>
              <td width="50%" bgcolor="#bebebe">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#000000</td>
              <td width="50%" bgcolor="#000000">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#030303</td>
              <td width="50%" bgcolor="#030303">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#1A1A1A</td>
              <td width="50%" bgcolor="#1a1a1a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFFFFF</td>
              <td width="50%" bgcolor="#ffffff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#1C1C1C</td>
              <td width="50%" bgcolor="#1c1c1c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#1F1F1F</td>
              <td width="50%" bgcolor="#1f1f1f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#212121</td>
              <td width="50%" bgcolor="#212121">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#242424</td>
              <td width="50%" bgcolor="#242424">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#262626</td>
              <td width="50%" bgcolor="#262626">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#292929</td>
              <td width="50%" bgcolor="#292929">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#2B2B2B</td>
              <td width="50%" bgcolor="#2b2b2b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#2E2E2E</td>
              <td width="50%" bgcolor="#2e2e2e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#303030</td>
              <td width="50%" bgcolor="#303030">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#050505</td>
              <td width="50%" bgcolor="#050505">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#333333</td>
              <td width="50%" bgcolor="#333333">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#363636</td>
              <td width="50%" bgcolor="#363636">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#383838</td>
              <td width="50%" bgcolor="#383838">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#3B3B3B</td>
              <td width="50%" bgcolor="#3b3b3b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#3D3D3D</td>
              <td width="50%" bgcolor="#3d3d3d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#404040</td>
              <td width="50%" bgcolor="#404040">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#424242</td>
              <td width="50%" bgcolor="#424242">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#454545</td>
              <td width="50%" bgcolor="#454545">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#474747</td>
              <td width="50%" bgcolor="#474747">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4A4A4A</td>
              <td width="50%" bgcolor="#4a4a4a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#080808</td>
              <td width="50%" bgcolor="#080808">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4D4D4D</td>
              <td width="50%" bgcolor="#4d4d4d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4F4F4F</td>
              <td width="50%" bgcolor="#4f4f4f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#525252</td>
              <td width="50%" bgcolor="#525252">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#545454</td>
              <td width="50%" bgcolor="#545454">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#575757</td>
              <td width="50%" bgcolor="#575757">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#595959</td>
              <td width="50%" bgcolor="#595959">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#5C5C5C</td>
              <td width="50%" bgcolor="#5c5c5c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#5E5E5E</td>
              <td width="50%" bgcolor="#5e5e5e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#616161</td>
              <td width="50%" bgcolor="#616161">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#636363</td>
              <td width="50%" bgcolor="#636363">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0A0A0A</td>
              <td width="50%" bgcolor="#0a0a0a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#666666</td>
              <td width="50%" bgcolor="#666666">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#696969</td>
              <td width="50%" bgcolor="#696969">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6B6B6B</td>
              <td width="50%" bgcolor="#6b6b6b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6E6E6E</td>
              <td width="50%" bgcolor="#6e6e6e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#707070</td>
              <td width="50%" bgcolor="#707070">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#737373</td>
              <td width="50%" bgcolor="#737373">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#757575</td>
              <td width="50%" bgcolor="#757575">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#787878</td>
              <td width="50%" bgcolor="#787878">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7A7A7A</td>
              <td width="50%" bgcolor="#7a7a7a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7D7D7D</td>
              <td width="50%" bgcolor="#7d7d7d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0D0D0D</td>
              <td width="50%" bgcolor="#0d0d0d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7F7F7F</td>
              <td width="50%" bgcolor="#7f7f7f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#828282</td>
              <td width="50%" bgcolor="#828282">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#858585</td>
              <td width="50%" bgcolor="#858585">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#878787</td>
              <td width="50%" bgcolor="#878787">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8A8A8A</td>
              <td width="50%" bgcolor="#8a8a8a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8C8C8C</td>
              <td width="50%" bgcolor="#8c8c8c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8F8F8F</td>
              <td width="50%" bgcolor="#8f8f8f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#919191</td>
              <td width="50%" bgcolor="#919191">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#949494</td>
              <td width="50%" bgcolor="#949494">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#969696</td>
              <td width="50%" bgcolor="#969696">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#0F0F0F</td>
              <td width="50%" bgcolor="#0f0f0f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#999999</td>
              <td width="50%" bgcolor="#999999">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9C9C9C</td>
              <td width="50%" bgcolor="#9c9c9c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9E9E9E</td>
              <td width="50%" bgcolor="#9e9e9e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A1A1A1</td>
              <td width="50%" bgcolor="#a1a1a1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A3A3A3</td>
              <td width="50%" bgcolor="#a3a3a3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A6A6A6</td>
              <td width="50%" bgcolor="#a6a6a6">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A8A8A8</td>
              <td width="50%" bgcolor="#a8a8a8">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#ABABAB</td>
              <td width="50%" bgcolor="#ababab">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#ADADAD</td>
              <td width="50%" bgcolor="#adadad">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B0B0B0</td>
              <td width="50%" bgcolor="#b0b0b0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#121212</td>
              <td width="50%" bgcolor="#121212">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B3B3B3</td>
              <td width="50%" bgcolor="#b3b3b3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B5B5B5</td>
              <td width="50%" bgcolor="#b5b5b5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B8B8B8</td>
              <td width="50%" bgcolor="#b8b8b8">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BABABA</td>
              <td width="50%" bgcolor="#bababa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BDBDBD</td>
              <td width="50%" bgcolor="#bdbdbd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BFBFBF</td>
              <td width="50%" bgcolor="#bfbfbf">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C2C2C2</td>
              <td width="50%" bgcolor="#c2c2c2">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C4C4C4</td>
              <td width="50%" bgcolor="#c4c4c4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C7C7C7</td>
              <td width="50%" bgcolor="#c7c7c7">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C9C9C9</td>
              <td width="50%" bgcolor="#c9c9c9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#141414</td>
              <td width="50%" bgcolor="#141414">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CCCCCC</td>
              <td width="50%" bgcolor="#cccccc">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CFCFCF</td>
              <td width="50%" bgcolor="#cfcfcf">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D1D1D1</td>
              <td width="50%" bgcolor="#d1d1d1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D4D4D4</td>
              <td width="50%" bgcolor="#d4d4d4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D6D6D6</td>
              <td width="50%" bgcolor="#d6d6d6">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D9D9D9</td>
              <td width="50%" bgcolor="#d9d9d9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DBDBDB</td>
              <td width="50%" bgcolor="#dbdbdb">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DEDEDE</td>
              <td width="50%" bgcolor="#dedede">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E0E0E0</td>
              <td width="50%" bgcolor="#e0e0e0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E3E3E3</td>
              <td width="50%" bgcolor="#e3e3e3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#171717</td>
              <td width="50%" bgcolor="#171717">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E5E5E5</td>
              <td width="50%" bgcolor="#e5e5e5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E8E8E8</td>
              <td width="50%" bgcolor="#e8e8e8">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EBEBEB</td>
              <td width="50%" bgcolor="#ebebeb">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EDEDED</td>
              <td width="50%" bgcolor="#ededed">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F0F0F0</td>
              <td width="50%" bgcolor="#f0f0f0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F2F2F2</td>
              <td width="50%" bgcolor="#f2f2f2">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F5F5F5</td>
              <td width="50%" bgcolor="#f5f5f5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F7F7F7</td>
              <td width="50%" bgcolor="#f7f7f7">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FAFAFA</td>
              <td width="50%" bgcolor="#fafafa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FCFCFC</td>
              <td width="50%" bgcolor="#fcfcfc">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name=Green>[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p>
        <TABLE cellPadding=3 width="100%" border=1>
          <TBODY>
            <TR> 
              <TH colSpan=2>Schattierungen von Gr�n</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#006400</td>
              <td width="50%" bgcolor="#006400">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BDB76B</td>
              <td width="50%" bgcolor="#bdb76b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#556B2F</td>
              <td width="50%" bgcolor="#556b2f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CAFF70</td>
              <td width="50%" bgcolor="#caff70">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BCEE68</td>
              <td width="50%" bgcolor="#bcee68">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A2CD5A</td>
              <td width="50%" bgcolor="#a2cd5a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6E8B3D</td>
              <td width="50%" bgcolor="#6e8b3d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8FBC8F</td>
              <td width="50%" bgcolor="#8fbc8f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C1FFC1</td>
              <td width="50%" bgcolor="#c1ffc1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B4EEB4</td>
              <td width="50%" bgcolor="#b4eeb4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9BCD9B</td>
              <td width="50%" bgcolor="#9bcd9b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#698B69</td>
              <td width="50%" bgcolor="#698b69">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#228B22</td>
              <td width="50%" bgcolor="#228b22">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#ADFF2F</td>
              <td width="50%" bgcolor="#adff2f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7CFC00</td>
              <td width="50%" bgcolor="#7cfc00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#20B2AA</td>
              <td width="50%" bgcolor="#20b2aa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#32CD32</td>
              <td width="50%" bgcolor="#32cd32">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#3CB371</td>
              <td width="50%" bgcolor="#3cb371">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00FA9A</td>
              <td width="50%" bgcolor="#00fa9a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F5FFFA</td>
              <td width="50%" bgcolor="#f5fffa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#6B8E23</td>
              <td width="50%" bgcolor="#6b8e23">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C0FF3E</td>
              <td width="50%" bgcolor="#c0ff3e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B3EE3A</td>
              <td width="50%" bgcolor="#b3ee3a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9ACD32</td>
              <td width="50%" bgcolor="#9acd32">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#698B22</td>
              <td width="50%" bgcolor="#698b22">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#98FB98</td>
              <td width="50%" bgcolor="#98fb98">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9AFF9A</td>
              <td width="50%" bgcolor="#9aff9a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#90EE90</td>
              <td width="50%" bgcolor="#90ee90">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7CCD7C</td>
              <td width="50%" bgcolor="#7ccd7c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#548B54</td>
              <td width="50%" bgcolor="#548b54">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#2E8B57</td>
              <td width="50%" bgcolor="#2e8b57">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#54FF9F</td>
              <td width="50%" bgcolor="#54ff9f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#4EEE94</td>
              <td width="50%" bgcolor="#4eee94">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#43CD80</td>
              <td width="50%" bgcolor="#43cd80">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#2E8B57</td>
              <td width="50%" bgcolor="#2e8b57">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00FF7F</td>
              <td width="50%" bgcolor="#00ff7f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00EE76</td>
              <td width="50%" bgcolor="#00ee76">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00CD66</td>
              <td width="50%" bgcolor="#00cd66">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#008B45</td>
              <td width="50%" bgcolor="#008b45">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9ACD32</td>
              <td width="50%" bgcolor="#9acd32">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7FFF00</td>
              <td width="50%" bgcolor="#7fff00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#76EE00</td>
              <td width="50%" bgcolor="#76ee00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#66CD00</td>
              <td width="50%" bgcolor="#66cd00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#458B00</td>
              <td width="50%" bgcolor="#458b00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00FF00</td>
              <td width="50%" bgcolor="#00ff00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00EE00</td>
              <td width="50%" bgcolor="#00ee00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#00CD00</td>
              <td width="50%" bgcolor="#00cd00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#008B00</td>
              <td width="50%" bgcolor="#008b00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F0E68C</td>
              <td width="50%" bgcolor="#f0e68c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFF68F</td>
              <td width="50%" bgcolor="#fff68f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEE685</td>
              <td width="50%" bgcolor="#eee685">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDC673</td>
              <td width="50%" bgcolor="#cdc673">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B864E</td>
              <td width="50%" bgcolor="#8b864e">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name=Orange>[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p>
        <TABLE cellPadding=3 width="100%" border=1>
          <TBODY>
            <TR> 
              <TH colSpan=2>Schattierungen von Orange</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF8C00</td>
              <td width="50%" bgcolor="#ff8c00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF7F00</td>
              <td width="50%" bgcolor="#ff7f00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE7600</td>
              <td width="50%" bgcolor="#ee7600">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD6600</td>
              <td width="50%" bgcolor="#cd6600">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B4500</td>
              <td width="50%" bgcolor="#8b4500">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E9967A</td>
              <td width="50%" bgcolor="#e9967a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F08080</td>
              <td width="50%" bgcolor="#f08080">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFA07A</td>
              <td width="50%" bgcolor="#ffa07a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFA07A</td>
              <td width="50%" bgcolor="#ffa07a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE9572</td>
              <td width="50%" bgcolor="#ee9572">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD8162</td>
              <td width="50%" bgcolor="#cd8162">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B5742</td>
              <td width="50%" bgcolor="#8b5742">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFDAB9</td>
              <td width="50%" bgcolor="#ffdab9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFDAB9</td>
              <td width="50%" bgcolor="#ffdab9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EECBAD</td>
              <td width="50%" bgcolor="#eecbad">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDAF95</td>
              <td width="50%" bgcolor="#cdaf95">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B7765</td>
              <td width="50%" bgcolor="#8b7765">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFE4C4</td>
              <td width="50%" bgcolor="#ffe4c4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFE4C4</td>
              <td width="50%" bgcolor="#ffe4c4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EED5B7</td>
              <td width="50%" bgcolor="#eed5b7">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDB79E</td>
              <td width="50%" bgcolor="#cdb79e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B7D6B</td>
              <td width="50%" bgcolor="#8b7d6b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF7F50</td>
              <td width="50%" bgcolor="#ff7f50">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF7256</td>
              <td width="50%" bgcolor="#ff7256">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE6A50</td>
              <td width="50%" bgcolor="#ee6a50">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD5B45</td>
              <td width="50%" bgcolor="#cd5b45">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B3E2F</td>
              <td width="50%" bgcolor="#8b3e2f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F0FFF0</td>
              <td width="50%" bgcolor="#f0fff0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E0EEE0</td>
              <td width="50%" bgcolor="#e0eee0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C1CDC1</td>
              <td width="50%" bgcolor="#c1cdc1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#838B83</td>
              <td width="50%" bgcolor="#838b83">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFA500</td>
              <td width="50%" bgcolor="#ffa500">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE9A00</td>
              <td width="50%" bgcolor="#ee9a00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD8500</td>
              <td width="50%" bgcolor="#cd8500">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B5A00</td>
              <td width="50%" bgcolor="#8b5a00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FA8072</td>
              <td width="50%" bgcolor="#fa8072">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF8C69</td>
              <td width="50%" bgcolor="#ff8c69">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE8262</td>
              <td width="50%" bgcolor="#ee8262">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD7054</td>
              <td width="50%" bgcolor="#cd7054">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B4C39</td>
              <td width="50%" bgcolor="#8b4c39">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A0522D</td>
              <td width="50%" bgcolor="#a0522d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF8247</td>
              <td width="50%" bgcolor="#ff8247">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE7942</td>
              <td width="50%" bgcolor="#ee7942">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD6839</td>
              <td width="50%" bgcolor="#cd6839">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B4726</td>
              <td width="50%" bgcolor="#8b4726">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name=Red>[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p>
        <TABLE cellPadding=3 width="100%" border=1>
          <TBODY>
            <TR> 
              <TH colSpan=2>Schattierungen von Rot</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF1493</td>
              <td width="50%" bgcolor="#ff1493">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE1289</td>
              <td width="50%" bgcolor="#ee1289">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD1076</td>
              <td width="50%" bgcolor="#cd1076">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B0A50</td>
              <td width="50%" bgcolor="#8b0a50">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF69B4</td>
              <td width="50%" bgcolor="#ff69b4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF6EB4</td>
              <td width="50%" bgcolor="#ff6eb4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE6AA7</td>
              <td width="50%" bgcolor="#ee6aa7">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD6090</td>
              <td width="50%" bgcolor="#cd6090">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B3A62</td>
              <td width="50%" bgcolor="#8b3a62">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD5C5C</td>
              <td width="50%" bgcolor="#cd5c5c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF6A6A</td>
              <td width="50%" bgcolor="#ff6a6a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE6363</td>
              <td width="50%" bgcolor="#ee6363">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD5555</td>
              <td width="50%" bgcolor="#cd5555">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B3A3A</td>
              <td width="50%" bgcolor="#8b3a3a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFB6C1</td>
              <td width="50%" bgcolor="#ffb6c1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFAEB9</td>
              <td width="50%" bgcolor="#ffaeb9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEA2AD</td>
              <td width="50%" bgcolor="#eea2ad">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD8C95</td>
              <td width="50%" bgcolor="#cd8c95">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B5F65</td>
              <td width="50%" bgcolor="#8b5f65">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#C71585</td>
              <td width="50%" bgcolor="#c71585">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFE4E1</td>
              <td width="50%" bgcolor="#ffe4e1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EED5D2</td>
              <td width="50%" bgcolor="#eed5d2">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDB7B5</td>
              <td width="50%" bgcolor="#cdb7b5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B7D7B</td>
              <td width="50%" bgcolor="#8b7d7b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF4500</td>
              <td width="50%" bgcolor="#ff4500">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE4000</td>
              <td width="50%" bgcolor="#ee4000">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD3700</td>
              <td width="50%" bgcolor="#cd3700">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B2500</td>
              <td width="50%" bgcolor="#8b2500">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DB7093</td>
              <td width="50%" bgcolor="#db7093">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF82AB</td>
              <td width="50%" bgcolor="#ff82ab">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE799F</td>
              <td width="50%" bgcolor="#ee799f">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD6889</td>
              <td width="50%" bgcolor="#cd6889">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B475D</td>
              <td width="50%" bgcolor="#8b475d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D02090</td>
              <td width="50%" bgcolor="#d02090">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF3E96</td>
              <td width="50%" bgcolor="#ff3e96">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE3A8C</td>
              <td width="50%" bgcolor="#ee3a8c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD3278</td>
              <td width="50%" bgcolor="#cd3278">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B2252</td>
              <td width="50%" bgcolor="#8b2252">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B22222</td>
              <td width="50%" bgcolor="#b22222">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF3030</td>
              <td width="50%" bgcolor="#ff3030">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE2C2C</td>
              <td width="50%" bgcolor="#ee2c2c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD2626</td>
              <td width="50%" bgcolor="#cd2626">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B1A1A</td>
              <td width="50%" bgcolor="#8b1a1a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFC0CB</td>
              <td width="50%" bgcolor="#ffc0cb">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFB5C5</td>
              <td width="50%" bgcolor="#ffb5c5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEA9B8</td>
              <td width="50%" bgcolor="#eea9b8">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD919E</td>
              <td width="50%" bgcolor="#cd919e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B636C</td>
              <td width="50%" bgcolor="#8b636c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF0000</td>
              <td width="50%" bgcolor="#ff0000">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE0000</td>
              <td width="50%" bgcolor="#ee0000">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD0000</td>
              <td width="50%" bgcolor="#cd0000">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B0000</td>
              <td width="50%" bgcolor="#8b0000">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF6347</td>
              <td width="50%" bgcolor="#ff6347">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE5C42</td>
              <td width="50%" bgcolor="#ee5c42">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD4F39</td>
              <td width="50%" bgcolor="#cd4f39">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B3626</td>
              <td width="50%" bgcolor="#8b3626">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name=Violet>[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p>
        <TABLE cellPadding=3 width="100%" border=1>
          <TBODY>
            <TR> 
              <TH colSpan=2>Schattierungen von Violett</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9932CC</td>
              <td width="50%" bgcolor="#9932cc">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BF3EFF</td>
              <td width="50%" bgcolor="#bf3eff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B23AEE</td>
              <td width="50%" bgcolor="#b23aee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9A32CD</td>
              <td width="50%" bgcolor="#9a32cd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#68228B</td>
              <td width="50%" bgcolor="#68228b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9400D3</td>
              <td width="50%" bgcolor="#9400d3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFF0F5</td>
              <td width="50%" bgcolor="#fff0f5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEE0E5</td>
              <td width="50%" bgcolor="#eee0e5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDC1C5</td>
              <td width="50%" bgcolor="#cdc1c5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B8386</td>
              <td width="50%" bgcolor="#8b8386">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#BA55D3</td>
              <td width="50%" bgcolor="#ba55d3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E066FF</td>
              <td width="50%" bgcolor="#e066ff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D15FEE</td>
              <td width="50%" bgcolor="#d15fee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B452CD</td>
              <td width="50%" bgcolor="#b452cd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7A378B</td>
              <td width="50%" bgcolor="#7a378b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9370DB</td>
              <td width="50%" bgcolor="#9370db">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#AB82FF</td>
              <td width="50%" bgcolor="#ab82ff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9F79EE</td>
              <td width="50%" bgcolor="#9f79ee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8968CD</td>
              <td width="50%" bgcolor="#8968cd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#5D478B</td>
              <td width="50%" bgcolor="#5d478b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#E6E6FA</td>
              <td width="50%" bgcolor="#e6e6fa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF00FF</td>
              <td width="50%" bgcolor="#ff00ff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE00EE</td>
              <td width="50%" bgcolor="#ee00ee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD00CD</td>
              <td width="50%" bgcolor="#cd00cd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B008B</td>
              <td width="50%" bgcolor="#8b008b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B03060</td>
              <td width="50%" bgcolor="#b03060">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF34B3</td>
              <td width="50%" bgcolor="#ff34b3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE30A7</td>
              <td width="50%" bgcolor="#ee30a7">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD2990</td>
              <td width="50%" bgcolor="#cd2990">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B1C62</td>
              <td width="50%" bgcolor="#8b1c62">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DA70D6</td>
              <td width="50%" bgcolor="#da70d6">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FF83FA</td>
              <td width="50%" bgcolor="#ff83fa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE7AE9</td>
              <td width="50%" bgcolor="#ee7ae9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD69C9</td>
              <td width="50%" bgcolor="#cd69c9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B4789</td>
              <td width="50%" bgcolor="#8b4789">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DDA0DD</td>
              <td width="50%" bgcolor="#dda0dd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFBBFF</td>
              <td width="50%" bgcolor="#ffbbff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEAEEE</td>
              <td width="50%" bgcolor="#eeaeee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD96CD</td>
              <td width="50%" bgcolor="#cd96cd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B668B</td>
              <td width="50%" bgcolor="#8b668b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#A020F0</td>
              <td width="50%" bgcolor="#a020f0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#9B30FF</td>
              <td width="50%" bgcolor="#9b30ff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#912CEE</td>
              <td width="50%" bgcolor="#912cee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#7D26CD</td>
              <td width="50%" bgcolor="#7d26cd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#551A8B</td>
              <td width="50%" bgcolor="#551a8b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#D8BFD8</td>
              <td width="50%" bgcolor="#d8bfd8">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFE1FF</td>
              <td width="50%" bgcolor="#ffe1ff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EED2EE</td>
              <td width="50%" bgcolor="#eed2ee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDB5CD</td>
              <td width="50%" bgcolor="#cdb5cd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B7B8B</td>
              <td width="50%" bgcolor="#8b7b8b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EE82EE</td>
              <td width="50%" bgcolor="#ee82ee">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name=White>[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p>
        <TABLE cellPadding=3 width="100%" border=1>
          <TBODY>
            <TR> 
              <TH colSpan=2>Schattierungen von Weiss</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FAEBD7</td>
              <td width="50%" bgcolor="#faebd7">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFEFDB</td>
              <td width="50%" bgcolor="#ffefdb">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEDFCC</td>
              <td width="50%" bgcolor="#eedfcc">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDC0B0</td>
              <td width="50%" bgcolor="#cdc0b0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B8378</td>
              <td width="50%" bgcolor="#8b8378">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFFAF0</td>
              <td width="50%" bgcolor="#fffaf0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F8F8FF</td>
              <td width="50%" bgcolor="#f8f8ff">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFDEAD</td>
              <td width="50%" bgcolor="#ffdead">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EECFA1</td>
              <td width="50%" bgcolor="#eecfa1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDB38B</td>
              <td width="50%" bgcolor="#cdb38b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B795E</td>
              <td width="50%" bgcolor="#8b795e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FDF5E6</td>
              <td width="50%" bgcolor="#fdf5e6">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F5F5F5</td>
              <td width="50%" bgcolor="#f5f5f5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DCDCDC</td>
              <td width="50%" bgcolor="#dcdcdc">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFFFF0</td>
              <td width="50%" bgcolor="#fffff0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEEEE0</td>
              <td width="50%" bgcolor="#eeeee0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDCDC1</td>
              <td width="50%" bgcolor="#cdcdc1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B8B83</td>
              <td width="50%" bgcolor="#8b8b83">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FAF0E6</td>
              <td width="50%" bgcolor="#faf0e6">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFF5EE</td>
              <td width="50%" bgcolor="#fff5ee">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEE5DE</td>
              <td width="50%" bgcolor="#eee5de">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDC5BF</td>
              <td width="50%" bgcolor="#cdc5bf">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B8682</td>
              <td width="50%" bgcolor="#8b8682">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFFAFA</td>
              <td width="50%" bgcolor="#fffafa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEE9E9</td>
              <td width="50%" bgcolor="#eee9e9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDC9C9</td>
              <td width="50%" bgcolor="#cdc9c9">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B8989</td>
              <td width="50%" bgcolor="#8b8989">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#F5DEB3</td>
              <td width="50%" bgcolor="#f5deb3">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFE7BA</td>
              <td width="50%" bgcolor="#ffe7ba">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EED8AE</td>
              <td width="50%" bgcolor="#eed8ae">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDBA96</td>
              <td width="50%" bgcolor="#cdba96">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B7E66</td>
              <td width="50%" bgcolor="#8b7e66">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFFFFF</td>
              <td width="50%" bgcolor="#ffffff">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name=Yellow>[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p>
        <TABLE cellPadding=3 width="100%" border=1>
          <TBODY>
            <TR> 
              <TH colSpan=2>Schattierungen von Gelb</TH>
            </TR>
            <TR> 
              <TH width="50%">Hex-Wert</TH>
              <TH width="50%">Farbe</TH>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFEBCD</td>
              <td width="50%" bgcolor="#ffebcd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#B8860B</td>
              <td width="50%" bgcolor="#b8860b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%" height="28">#FFB90F</td>
              <td width="50%" bgcolor="#ffb90f" height="28">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEAD0E</td>
              <td width="50%" bgcolor="#eead0e">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD950C</td>
              <td width="50%" bgcolor="#cd950c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B6508</td>
              <td width="50%" bgcolor="#8b6508">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFFACD</td>
              <td width="50%" bgcolor="#fffacd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEE9BF</td>
              <td width="50%" bgcolor="#eee9bf">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDC9A5</td>
              <td width="50%" bgcolor="#cdc9a5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B8970</td>
              <td width="50%" bgcolor="#8b8970">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEDD82</td>
              <td width="50%" bgcolor="#eedd82">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFEC8B</td>
              <td width="50%" bgcolor="#ffec8b">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEDC82</td>
              <td width="50%" bgcolor="#eedc82">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDBE70</td>
              <td width="50%" bgcolor="#cdbe70">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B814C</td>
              <td width="50%" bgcolor="#8b814c">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FAFAD2</td>
              <td width="50%" bgcolor="#fafad2">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFFFE0</td>
              <td width="50%" bgcolor="#ffffe0">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEEED1</td>
              <td width="50%" bgcolor="#eeeed1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDCDB4</td>
              <td width="50%" bgcolor="#cdcdb4">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B8B7A</td>
              <td width="50%" bgcolor="#8b8b7a">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEE8AA</td>
              <td width="50%" bgcolor="#eee8aa">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFEFD5</td>
              <td width="50%" bgcolor="#ffefd5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFF8DC</td>
              <td width="50%" bgcolor="#fff8dc">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEE8CD</td>
              <td width="50%" bgcolor="#eee8cd">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDC8B1</td>
              <td width="50%" bgcolor="#cdc8b1">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B8878</td>
              <td width="50%" bgcolor="#8b8878">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFD700</td>
              <td width="50%" bgcolor="#ffd700">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEC900</td>
              <td width="50%" bgcolor="#eec900">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDAD00</td>
              <td width="50%" bgcolor="#cdad00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B7500</td>
              <td width="50%" bgcolor="#8b7500">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#DAA520</td>
              <td width="50%" bgcolor="#daa520">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFC125</td>
              <td width="50%" bgcolor="#ffc125">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEB422</td>
              <td width="50%" bgcolor="#eeb422">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CD9B1D</td>
              <td width="50%" bgcolor="#cd9b1d">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B6914</td>
              <td width="50%" bgcolor="#8b6914">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFE4B5</td>
              <td width="50%" bgcolor="#ffe4b5">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#FFFF00</td>
              <td width="50%" bgcolor="#ffff00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#EEEE00</td>
              <td width="50%" bgcolor="#eeee00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#CDCD00</td>
              <td width="50%" bgcolor="#cdcd00">&nbsp;</td>
            </TR>
            <TR align="middle"> 
              <td width="50%">#8B8B00</td>
              <td width="50%" bgcolor="#8b8b00">&nbsp;</td>
            </TR>
          </TBODY>
        </TABLE>
        <P><A href="#top" name=copying>[Zur&uuml;ck zur Farb&uuml;bersicht]</A></p>
        <P></p> 
        <HR width="100%" noShade> </TD>
    </TR>
  </TBODY>
</TABLE>
</BODY>
</HTML>